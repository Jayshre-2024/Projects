from django.apps import AppConfig


class CouponConfig(AppConfig):
    name = 'coupon'
